package com.cg.billing.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
@Controller
public class billingServicesController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping(value= {"/acceptCustomerDetails"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<Customer> acceptCustomerDetails(@ModelAttribute Customer customer){
		customer=billingServices.acceptCustomerDetails(customer);
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	@RequestMapping(value= {"/openPostpaidAccount"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<Long> openPostpaidAccount(@RequestParam int customerID, int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException{
		long mobileNumber=billingServices.openPostpaidMobileAccount(customerID, planID);
		return new ResponseEntity<Long>(mobileNumber,HttpStatus.OK);
	}
	@RequestMapping(value= {"/generateBill"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<Double> generateBill(@RequestParam int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, PlanDetailsNotFoundException{
		return new ResponseEntity<Double>(billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits),HttpStatus.OK);
	}
	@RequestMapping(value= {"/getCustomerDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> getCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException{
		return new ResponseEntity<Customer>(billingServices.getCustomerDetails(customerID),HttpStatus.OK);
	}
	@RequestMapping(value= {"/allCustomerDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Customer>> getAllCustomerDetails(){
		return new ResponseEntity<List<Customer>>(billingServices.getAllCustomerDetails(),HttpStatus.OK);
	}
	@RequestMapping(value= {"/getPostpaidAccountDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PostpaidAccount> getPostpaidAccountDetails(@RequestParam int customerID, long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException{
		return new ResponseEntity<PostpaidAccount>(billingServices.getPostPaidAccountDetails(customerID, mobileNo),HttpStatus.OK);
	}
	@RequestMapping(value= {"/allPostpaidAccountDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<PostpaidAccount>> getAllPostpaidAccountDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException{
		return new ResponseEntity<List<PostpaidAccount>>(billingServices.getCustomerAllPostpaidAccountsDetails(customerID),HttpStatus.OK);
	}
	
}
