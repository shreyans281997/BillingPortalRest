package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.product.beans.Product;
import com.cg.product.daoservices.IProductRepo;
import com.cg.product.exceptions.ProductNotFoundException;
@Component("productService")
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductRepo productRepo;
	//to insert new product
	@Override
	public String createProduct(Product product) {
		product=productRepo.save(product);
		return product.getId();
	}
	//to update previous product
	@Override
	public Product updateProduct(Product product) throws ProductNotFoundException {
		return productRepo.save(product);
	}
	//to delete product from database
	@Override
	public boolean deleteProduct(String productId) throws ProductNotFoundException {
		findProduct(productId);
		productRepo.delete(findProduct(productId));
		return true;
	}
	//to view all products
	@Override
	public List<Product> viewProducts() {
		return productRepo.findAll();
	}
	//to find product from database
	@Override
	public Product findProduct(String productId) throws ProductNotFoundException {
		return productRepo.findById(productId).orElseThrow(()->new ProductNotFoundException("PRODUCT NOT AVAILABLE WITH ID:"+productId));
	}

}
