package com.cg.product.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.product.beans.Product;
import com.cg.product.exceptions.ProductNotFoundException;
import com.cg.product.services.IProductService;
@Controller
public class ProductController {
	@Autowired
	private IProductService services;
	 @RequestMapping(value="/acceptProductDetails",method=RequestMethod.POST, 
				consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
		public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
		 String productId=services.createProduct(product);
			return new ResponseEntity<>("Product details successfully added with ID:- "+productId,HttpStatus.OK);
		}
	 @RequestMapping(value= {"/products/{id}"},method=RequestMethod.PUT,headers="Accept=application/json")
		public ResponseEntity<Product> updateDetailsPathParam(@PathVariable(value="id")String productId, @RequestBody Product product) throws ProductNotFoundException{
			product=services.updateProduct(product);
			return new ResponseEntity<Product>(product,HttpStatus.OK);
   } 
	 @RequestMapping(value= {"/getProductDetails/{id}"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
		public ResponseEntity<Product> getProductDetailsPathParam(@PathVariable(value="id") String id) throws ProductNotFoundException{
			Product product=services.findProduct(id);
			return new ResponseEntity<Product>(product,HttpStatus.OK);
} 
	 @RequestMapping(value= {"/getProductDetails"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
		public ResponseEntity<Product> getproductDetailsRequestParam(@RequestParam String id) throws ProductNotFoundException{
			Product product=services.findProduct(id);
			return new ResponseEntity<Product>(product,HttpStatus.OK); 
}
	 @RequestMapping(value="/deleteProduct/{productId}",method=RequestMethod.DELETE,
				consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
		public ResponseEntity<String> removeProductDetails(@PathVariable(value="productId") String id) throws ProductNotFoundException{
			services.deleteProduct(id);
			return new ResponseEntity<>("Product removed successfully",HttpStatus.OK);
		}
	 @RequestMapping(value= {"/products"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
		public ResponseEntity<List<Product>> getproductDetailsRequestParam(){
			List<Product> products=services.viewProducts();
			return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
		}
}
